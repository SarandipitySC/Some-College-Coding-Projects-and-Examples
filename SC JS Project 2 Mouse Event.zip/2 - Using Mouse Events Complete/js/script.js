/* Using Mouse Events */


var logoimg = document.getElementById("otherimage");

/* Create a small function called changeAnImage that will change the image from oulander.gif to spices.jpg
attach that function to the mouseover event*/


/*logoimg.onmouseover =*/

function changeanimage(){

  document.getElementById("otherimage").src='images/spices.jpg';
}

/*create a small function called changeImageBack and attach to the mouseout event
*/

/*logoimg.onmouseout =*/

 function changeimageback() {
  document.getElementById("otherimage").src='images/outlander.gif';

 }
 


/*STEP TWO - comment out the lines where you attached the event handlers and move to inline javascript.
The difference in the syntax:

using the onclick "attribute" in html is just like any other attribute.  Use an equals and quotes.
When we refer to the functions, we DO use the (_) in the call in HTML */



