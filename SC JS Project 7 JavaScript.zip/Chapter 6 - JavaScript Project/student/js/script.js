/* for each of the contacts, let's display all of them, each in its own paragraph, and use concatination in our function

What type of thing figure out how many contacts are in the list!!
Add Two more names and email addresses to write out to the screen

"Grab" our button and our area that will be updated

create a function that will loop through the contacts and display them using Name and Email address - in bold and try to put EXACTLY three spaces between the colons in your titles and the data (see the board)

DO NOT REMOVE THE Header inside the box

Then make sure that the button is awaiting your action so that the list shows up - final line in JS to tie the button, the function and the event together!
Try to show the list only once...
*/

var tealbtn = document.getElementById("contactlistbutton");

var contacts = {
    "addressBook" : [
        {
            "name":   "Matt Stratton",
            "email":   "matt@example.com",
        },
        {
            "name":   "Ted Willis",
            "email":   "bigboy@example.com",
        },
        {
            "name":   "Clint Eastwood",
            "email":   "clint@example.com",
        },
        {
            "name":   "Jennifer Aniston",
            "email": "aniston@example.com",
        },
		 {
            "name":   "Sarah Perozo",
            "email":   "Sarandipity@example.com",
        },
		 {
            "name":   "Ace Perozo",
            "email":   "ACEREEL@example.com",
        }
		
    ]

};

var showContacts = {

	loopcontactlist:function() {
		var target = document.getElementById("para");
		var list = contacts.addressBook; 
		var contactsCount = list.length; 
		var i;
		
				if(contactsCount > 0) {
		
					for(i = 0; i <contactsCount; i++){
					 
						var item = list[i],
							name = item.name,
							email = item.email;
							
							target.innerHTML += '<p>' + name + ':   <a href="mailto:' + email + '">' + email + '</a></p>'; 
						
							
						}
					}	
				tealbtn.disabled = true;	
				}
			
		
	};

tealbtn.addEventListener("click", showContacts.loopcontactlist, false);