/*. In Javascript
Create JSON notion for three states, NC, SC, and FL - IN THAT ORDER
Create the JSON object variable name "states"
Inside of states, the object will refer to ONLY ONE array called eachstate Do not use the two letter IDs for the states here... This is an ARRAY - no names...
eachstate should be an array containing three (unnamed) objects - these objects are contained inside an array (comma delimited!)
In each object inside the array - reuse the name, capital, population, and bird from the other example but remember what happens to each item on the LEFT side of the colon.*/


var btn = document.getElementById("onlysc");


var states = {
	
	"eachstate" : [ 
	{
		"name":":  North Carolina",
		"capital":":  Raliegh",
		"population":": 464,758",
		"bird":":  Cardinal",
	
	},
	{
		"name":"  South Carolina",
		"capital":":  Columbia",
		"population":":  133,114",
		"bird":":  Carolina Wren & Wild Turkey",
	
	},
	{
		"name":":  Florida",
		"capital":":  Tallahassee",
		"population":":  191,049",
		"bird":":  Northern Mockingbird",
	
	}
	
]
	
};



function replaceParagraph() {
    document.getElementById("para").innerHTML = "<p>name:"+ states.eachstate[1].name+"</p>"+"<p>"+"capital"+states.eachstate[1].capital+"</p>"+"<p>"+"population"+states.eachstate[1].population+"</p>"+"<p>"+"bird"+states.eachstate[1].bird+"</p>" 
    }

btn.addEventListener("click", replaceParagraph, false);




