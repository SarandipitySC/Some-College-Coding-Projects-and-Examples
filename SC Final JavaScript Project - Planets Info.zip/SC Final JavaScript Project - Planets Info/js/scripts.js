
/* Grab the elements you need, you may do it all at the top or in each of your exercises */

var jupiterbtn = document.getElementById("jupiterFacts");

var mercurybtn = document.getElementById("mercuryInfo");

var sunbtn = document.getElementById("sunbutton")

/* create the code for hiding your paragraph when you roll over the sun, 
remove the mouse and bring the paragraph back.  Use your event handlers 
 */

function paraGone(){
	 document.getElementById("burnpara").innerHTML = (" ");
    }

function paraBack(){
	document.getElementById("burnpara").innerHTML = "Move your mouse over the sun, and see something fun!" ;
    }


 sunbtn.addEventListener("mouseover", paraGone, false);

 sunbtn.addEventListener("mouseout", paraBack, false);




/* Create an object holding one SIMPLE array of 4 pieces of information about Mercury.  Show all facts in an alert.
 Create a function that when a button is clicked will pop up the Mercury information formatted nicely, like the instructor's...

Mercury is the smallest planet.
Mercury is the messanger god.
Mercury is red.
Mercury is also in thermometers.


Use an event listener in this one
 */


var mercuryfacts = {

		One: "  Mercury is the smallest planet.",
		Two: "  Mercury is the messanger god.",
		Three: "  Mercury is red.",
		Four: "  Mercury is also in thermometers.",

			};

function popup() {
	
	alert("Mercury Facts:" + mercuryfacts.One + "\n & " + mercuryfacts.Two + "\n & " + mercuryfacts.Three + "\n & " + mercuryfacts.Four);
		
}

mercurybtn.addEventListener("click", popup, false)



/* Create a JSON object of Jupiter information.  You might want to put an array in your object for the "looping" part of this!
When someone clicks the button, loop through all of the information, but in one chunk display it all in a paragraph ABOVE the button.

Make the sentence: has a big storm - red
Make the sentence: has four moons - bigger than the rest

is the largest planet
has a big storm
has four moons
spins faster than any other planet
is 483,682,810 miles from the sun
*/


var jupiter = {
    "jupifacts" : [
        {
            "fact":   "is the largest planet",
        },
        {
            "fact":   "has a big storm",
        },
        {
            "fact":   "has four moons",
        },
        {
            "fact":   "spins faster than any other planet",
        },
		 {
            "fact":   "is 483,682,810 miles from the sun",
        }		
    ]
};

var showJupiFacts = {

	loopJupiFacts:function() {
		var target = document.getElementById("replacepara");
		var list = jupiter.jupifacts; 
		var factsCount = list.length; 
		var i;
		
				if(factsCount > 0) {
		
					for(i = 0; i <factsCount; i++){
					 
						var item = list[i],
							facts = item.fact;
							
							
							target.innerHTML += "<p>" + facts + "</p>" 		

							
						}
					}	
				jupiterbtn.disabled = true;	
				}
			
		
	};

jupiterbtn.addEventListener("click", showJupiFacts.loopJupiFacts, false);


















/* BEFORE you zip it all up - RENAME your js file to a txt file.  It will not go through email */