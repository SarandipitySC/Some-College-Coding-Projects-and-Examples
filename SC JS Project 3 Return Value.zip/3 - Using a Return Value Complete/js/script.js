
//grab the form

document.getElementsById("nameform");


//create a function so that when we submit the form, we will validate using the javascript function on the form element itself 
// using the event listener does not work here yet - due to extra code, 
//so use the event handler and handle the event "submit" on the form itself,  not the submit input 

//in your function, create a small if and else statement
//if the name does NOT match your name , return a boolean of false
// else return a boolean of true
//When you grab the element node for the first name field - use .value to figure out what the user has entered



function validateform() {
	
var name1 = document.forms["nameform"]["myname"].value;

if (name1 == "Sarah"){	  
    return true;
} 

else {
	alert("That is not a known name for me! As far as I know, I haven't been called that yet.");
	return false;
	}
}




//PROJECT TWO - we will move this function to inline JavaScript