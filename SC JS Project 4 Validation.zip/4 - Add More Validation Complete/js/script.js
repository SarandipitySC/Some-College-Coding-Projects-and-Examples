/* Grab the value of the color field and if it is red then return false with a message, 
if it is yellow, give a different message
if it is green (or your favorite color) allow it to post
all other colors, do not allow it to post - you may give a different message - be creative!

Do not use an event listener, use the event handler on the form to stop the submit.  Use your return keyword in the online javascript

Create another function that will validate just the number field
Use the event for tabbing out of a field - when someone tabs out of the number field 
if the number is less than 100, return an alert that lets the user know that they should go to an ATM

*** a little extra... Find the function online that will turn a string into a number so that the condition will work...

*** a little more - try to find the function online that will allow the user to spell the colors correctly but use upper or lower case letters

*/

document.getElementById("GuessColor")


function correctColor(){
  var enteredColor = document.forms["GuessForm"]["guesscolor"].value;
	  if (enteredColor == "green" || enteredColor == "purple" || enteredColor == "teal") { alert("Correct! You guessed one out of my three favorite colors. Can you guess them all?");
		return true;
	  } else if (enteredColor == "red"){ alert("Red is close to Garnet, but still not one of my favorite colors.");
			return false;
		  } else if (enteredColor == "yellow"){ alert("Yellow is Ace's Favorite Color, Not Mine!");
				return false;
			  } else { alert("Keep trying, there are only Oh So Many Colors!");
				return false;
			  }
}



document.getElementsById("moneypocket")


function correctMoney(){
  var enteredMoney = document.forms["GuessForm"]["MoneyPocket"].value;
	  if (enteredMoney<100){ alert("You should go to the ATM");
		return false;
	  } else if (enteredMoney>100){ alert("Let's talk business!");
		  return true;
		} else { alert("Maybe next time.");
			return false;
					  }
}








