/* Lesson 1 page 125 using the onclick Event Handler */
var btn = document.getElementById("btn");


/* Create a small function called changeAnImage that will change the image from  outlander.gif to spices.jpg*/

btn.onclick = function changeAnImage() {
	document.getElementById("theDiv").innerHTML = "<img src=images/spices.jpg />";
	
		}

/* Using the event handler, attache the function to the onclick event like on page 125 */

