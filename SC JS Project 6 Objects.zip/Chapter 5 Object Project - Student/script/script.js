
	


var btn = document.getElementById("onlysc");


var eachstate = {

	NC : 
			{
		Name: "  North Carolina",
		Capital: "  Raliegh",
		Population: "  464,758",
		Bird: "  Cardinal",

			},
	SC : 
			{
			Name: "  South Carolina",
			Capital: "  Columbia",
			Population: "  133,114",
			Bird: "  Carolina Wren & Wild Turkey",
			},
		
	FL : 
			{
			Name: "  Florida",
			Capital: "  Tallahassee",
			Population: "  191,049",
			Bird: "  Northern Mockingbird",
			},
		
};


function popup() {
	
	alert("Name:" + eachstate.SC.Name + "\nCapital:" + eachstate.SC.Capital + "\nPopulation:" + eachstate.SC.Population + "\nBird:" + eachstate.SC.Bird);
		
}

btn.addEventListener("click", popup, false)




	//* alert("Name:" + eachstate.FL.name + "\nCapital:" + eachstate.FL.capital + "\nPopulation:" + eachstate.FL.population + "\nBird:" + eachstate.FL.bird);*\\
	//*alert("Name:" + eachstate.NC.name + "\nCapital:" + eachstate.NC.capital + "\nPopulation:" + eachstate.NC.population + "\nBird:" + eachstate.NC.bird);*\\

